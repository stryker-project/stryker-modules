apk add apk add libgcrypt libidn mariadb-dev pcre2-dev postgresql-dev subversion-dev libssh freerdp-libs
echo "Finished. Reboot app!"