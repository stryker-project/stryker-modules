rm geomac
echo "Finished. Reboot app!"