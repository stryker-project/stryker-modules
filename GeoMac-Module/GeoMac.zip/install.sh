chmod 777 geomac
echo "Finished. Reboot app!"